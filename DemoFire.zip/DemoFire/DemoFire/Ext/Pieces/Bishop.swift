//
//  Bishop.swift
//  DemoFire
//
//  Created by Dwayne Reinaldy on 5/27/22.
//

import Foundation

class Bishop: RecursivePiece {
    
    let id = UUID().hashValue
            
    let type = PieceType.bishop
    
    let side: Side
    
    let points = 3
    
    let moveDirections = Coordinate.Direction.diagonals
    
    init(_ side: Side) {
        self.side = side
    }
        
}
