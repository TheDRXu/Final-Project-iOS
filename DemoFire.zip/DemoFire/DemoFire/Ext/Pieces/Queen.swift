//
//  Queen.swift
//  DemoFire
//
//  Created by Dwayne Reinaldy on 5/27/22.
//

import Foundation

class Queen: RecursivePiece {
    
    let id = UUID().hashValue
            
    let type = PieceType.queen
    
    let side: Side
    
    let points = 9
    
    let moveDirections = Coordinate.Direction.all
    
    init(_ side: Side) {
        self.side = side
    }
    
}
