//
//  Rook.swift
//  DemoFire
//
//  Created by Dwayne Reinaldy on 5/27/22.
//

import Foundation

struct Rook: RecursivePiece {
    
    let id = UUID().hashValue
            
    let type = PieceType.rook
    
    let side: Side
    
    let points = 5
    
    let moveDirections = Coordinate.Direction.verticalHorizontals
    
    init(_ side: Side) {
        self.side = side
    }

}
