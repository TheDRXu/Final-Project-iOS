//
//  Player.swift
//  DemoFire
//
//  Created by Dwayne Reinaldy on 5/27/22.
//

import Foundation

class Player {
    var side: Side
    
    init(side: Side) {
        self.side = side
    }
    
}
